package com.jatayu.main.map.splash;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.look.ContainerTab;
import com.jatayu.main.map.look.Location;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.sqlite.DBHandler;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class Splash extends Activity {
	private ViewFlipper viewFlipper;
    private float lastX;
    int counter=1;
    private LoginButton loginButton;
    private CallbackManager callbackManager;
    private SharedPreferences sharedpreferences;
    RequestParams params;
    
    
    String showMitID;
    String emailP;
    String facebookId;
    
    SharedPreferences prefs =null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	String fontPath = "font/youngserif-regular.ttf";
        
    	
        //facebook
    	params = new RequestParams();
        
    	/*prefs = getSharedPreferences("Jatayu_User_Detail",
                Context.MODE_PRIVATE);
    	
    	String emailP= prefs.getString("user_email","");
    	String userIdP=prefs.getString("facebook_id", "");*/
    	
    
    DBHandler dbh= new DBHandler(getApplicationContext());
	Cursor cursor = dbh.readAllRow(dbh);
		if (cursor !=null)
		{
		while(cursor.moveToNext()){
			 showMitID 	= cursor.getString(0);
			 facebookId	=	cursor.getString(1);
			 emailP				= cursor.getString(3);
			 Log.e("","MITID DISPLAYED "+showMitID);
		    // Log.e("","GDT "+google_distance_time+" wait "+wait_time);
			}
		cursor.close(); 
		}
    	if (!TextUtils.isEmpty(emailP) || !TextUtils.isEmpty(facebookId)) {
            Intent i = new Intent(getApplicationContext(), Location.class);
           // i.putExtra("regId", registrationId);
            startActivity(i);
            finish();
        }
        
    	FacebookSdk.sdkInitialize(getApplicationContext());
        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.jatayu.main.map.splash", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.e("SHA: ", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
      
        }
        
        setContentView(R.layout.splash);
        TextView txtGhost = (TextView) findViewById(R.id.mitLogo);
    	Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);
    	
    	txtGhost.setTypeface(tf);
    	txtGhost.setShadowLayer(10, 2, 0, Color.GRAY);
        
        loginButton = (LoginButton) findViewById(R.id.login_button);
        
        //LoginManager.getInstance().logInWithReadPermissions(Splash.this, Arrays.asList("public_profile", "email"));
        //callbackManager = CallbackManager.Factory.create();
        
        
        FacebookSdk.sdkInitialize(Splash.this);
        callbackManager = CallbackManager.Factory.create();
        loginButton.setReadPermissions(Arrays.asList("public_profile, email, user_birthday"));

      

        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(final LoginResult loginResult) {
                Log.e("","Inside");
                
            	// App code
                GraphRequest request = GraphRequest.newMeRequest(
                        loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                        	 
                        	@Override
                            public void onCompleted(
                                    JSONObject object,
                                    GraphResponse response) {
                        		
                                // Application code
                        		try {
                        			
									String userId	=	object.getString("id");
									String name		=	object.getString("name");
									String email 	=	object.getString("email");
									//String mitID	=	object.getString("mit_user_id"); 
									/*Editor editor 	= 	prefs.edit();
									editor.putString("facebook_id", userId);
					        		editor.putString("user_name", name);
					        		editor.putString("user_email", email);
					        		editor.commit();*/
					        		//String a=prefs.getString("mit_user_id", "");
					        		pushToServer(userId,name,email);
					        		//Log.e("","a "+a);
					        	
									
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
                                Log.e("LoginActivity", object.toString());
                            }
                        });
               
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,email");
                request.setParameters(parameters);
                request.executeAsync();
        
        
               
            	
            	
            }

           

			@Override
            public void onCancel() {
                Log.e("","Login attempt cancelled.");
            }

            @Override
            public void onError(FacebookException e) {
                e.printStackTrace();
                Log.e("","Login attempt failed.");
            }
        });
    
        viewFlipper 		= 	(ViewFlipper) findViewById(R.id.viewflipper);
    }

    
    // Using the following method, we will handle all screen swaps.
    public boolean onTouchEvent(MotionEvent touchevent) {
    	switch (touchevent.getAction()) {
        
        case MotionEvent.ACTION_DOWN: 
        	lastX = touchevent.getX();
            break;
        case MotionEvent.ACTION_UP: 
            float currentX = touchevent.getX();
            
            // Handling left to right screen swap.
            if (lastX < currentX) {
            	
            	// If there aren't any other children, just break.
                if (viewFlipper.getDisplayedChild() == 0)
                	break;
                
                // Next screen comes in from left.
                viewFlipper.setInAnimation(this, R.anim.slide_in_from_left);
                // Current screen goes out from right. 
                viewFlipper.setOutAnimation(this, R.anim.slide_out_to_right);
                
                // Display next screen.
                viewFlipper.showNext();
             }
                                     
            // Handling right to left screen swap.
             if (lastX > currentX) {
            	 
            	 // If there is a child (to the left), kust break.
            	 if (viewFlipper.getDisplayedChild() == 1)
            		 break;
    
            	 // Next screen comes in from right.
            	 viewFlipper.setInAnimation(this, R.anim.slide_in_from_right);
            	// Current screen goes out from left. 
            	 viewFlipper.setOutAnimation(this, R.anim.slide_out_to_left);
                 
            	// Display previous screen.
                 viewFlipper.showPrevious();
             }
             break;
    	 }
         return false;
    }
    
    private void changeMyPosition() {
        // Next screen comes in from left.
        	viewFlipper.setOutAnimation(this, R.anim.slide_out_to_left);
        	// Current screen goes out from right. 
        	viewFlipper.setInAnimation(this, R.anim.slide_in_from_right);
        
        	// Display next screen.
        	viewFlipper.showNext();
	
	}
    private void pushToServer(final String fbId, final String fbUserName, final String fbEmail)
    {
    	params.put("facebook_id", fbId);
    	params.put("user_name", fbUserName);
    	params.put("email_id", fbEmail);
    	
    	AsyncHttpClient client = new AsyncHttpClient();
        client.post(NetworkIp.REGISTER_URL, params,
                new AsyncHttpResponseHandler() {
                    // When the response returned by REST has Http
                    // response code '200'
                    @Override
                    public void onSuccess(String response) {
                        // Hide Progress Dialog
                    	String mitID = null;
                    	
                    	
                    	
	                	 try
	                     {
	                	   JSONObject mainJson 	= 	new JSONObject(response);
	                	   Log.e("","response "+response);
	                  	   JSONArray jsonArray	= 	mainJson.getJSONArray("data");
	                       Log.e("Point","Yes 2");
	                       JSONObject objJson = new JSONObject(response);
	                       String success = null;
	                      // ArrayList<String> userNameAL = new ArrayList<String>();
	                       for (int i 	= 0; i < jsonArray.length(); i++) {
	                           objJson = jsonArray.getJSONObject(i);
	                           success		= 	objJson.getString("success");
	                           mitID		=	objJson.getString("mit_user_id");
	                       }
	                      // Log.e("","Splash "+mitID);
	                      /* Editor editor 	= 	prefs.edit();
	                       editor.putString("mit_user_id", mitID);
	                       Log.e("","EDITOR "+editor);
	                       editor.commit();*/
	                       Log.e("","mmmmmee "+mitID);
	                       
	                       
	                       //getting MIT id from server which is important and then saving it into sqlite
			        		DBHandler dbh			= 	new DBHandler(getApplicationContext());
			        		int catchInsertData	=	dbh.putInformation(dbh, mitID, fbId, fbUserName, fbEmail);
			        		 Toast.makeText(getApplicationContext(), "MIT ID "+mitID, Toast.LENGTH_LONG).show();
				                		
			        		if(mitID != null 	|| catchInsertData  != 0){
			        			Intent i 	=		new Intent(Splash.this,Location.class);
			        			startActivity(i);
			        			finish();
			            	}
	                     
	                     }catch(Exception e)
	                     {e.printStackTrace();}
	                	 Toast.makeText(getApplicationContext(), "EXCEPTION ", Toast.LENGTH_LONG).show();
	 	                
	                	 //	 Toast.makeText(getApplicationContext(), "Success Saev", Toast.LENGTH_LONG).show();
                    }
 
                    // When the response returned by REST has Http
                    // response code other than '200' such as '404',
                    // '500' or '403' etc
                    @Override
                    public void onFailure(int statusCode, Throwable error,
                            String content) {
                        // Hide Progress Dialog
                      
                        // When Http response code is '404'
                        if (statusCode == 404) {
                            Toast.makeText(getApplicationContext(),
                                    "Requested resource not found",
                                Toast.LENGTH_LONG).show();
                        }
                        
                        // When Http response code is '500'
                        else if (statusCode == 500) {
                            Toast.makeText(getApplicationContext(),
                                    "Something went wrong at server end",
                                    Toast.LENGTH_LONG).show();
                        }
                        // When Http response code other than 404, 500
                        else {
                            Toast.makeText(
                                    getApplicationContext(),
                                    "Unexpected Error occcured! [Most common Error: Device might "
                                            + "not be connected to Internet or remote server is not up and running], check for other errors as well",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
   
 
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private String message(Profile profile) {
        StringBuilder stringBuffer = new StringBuilder();
        if (profile != null) {
            stringBuffer.append("Welcome ").append(profile.getName());
        }
        return stringBuffer.toString();
    }

}