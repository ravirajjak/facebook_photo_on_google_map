package com.jatayu.main.map.friends;

/*
 * Copyright 2015 Bruno Romeu Nunes
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bumptech.glide.Glide;
import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.sqlite.DBHandler;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;


public class RecievedFriendRequest extends ActionBarActivity {
    private CardViewAdapter mAdapter;
    RequestParams params,par;
    private ArrayList<String> mItems;
    ArrayList<String> fbUserName;
    ArrayList<String> fbUserId;
    ArrayList<String> mitIdArrayList;
    
    String showMitID =null;
    int counter=0;
    int friendUserMitId=0;
    
    private Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend_request_received);
        
        par 							=	new RequestParams();
        params 					= new RequestParams(); 
        fbUserName			=	new ArrayList<String>();
        fbUserId					= new ArrayList<String>();
        mitIdArrayList	= new ArrayList<String>();
    
        
        mToolbar = (Toolbar) findViewById(R.id.toolbar_friends);
		setSupportActionBar(mToolbar);
		
		
		
		//getSupportActionBar().setDisplayShowHomeEnabled(true);
//		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setTitle("Friend Request");
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		
		mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		
       /* LinearLayout mainLayout = (LinearLayout) findViewById(R.id.linearFriendRequest);
        ColorDrawable[] color = {new ColorDrawable(Color.BLUE), new ColorDrawable(Color.RED)};
        TransitionDrawable trans = new TransitionDrawable(color);
        //This will work also on old devices. The latest API says you have to use setBackground instead.
        mainLayout.setBackgroundDrawable(trans);
        trans.startTransition(5000);*/
        
        
		DBHandler dbh	= new DBHandler(getApplicationContext());
		Cursor cursor 		= dbh.readMitId(dbh);	
		while(cursor.moveToNext()){
			 showMitID 	= cursor.getString(0);
			 Log.e("","MITID DISPLAYED "+showMitID);
		    // Log.e("","GDT "+google_distance_time+" wait "+wait_time);
		 }
		cursor.close(); 	
		sendMitId();
		Toast.makeText(getApplicationContext(), "Wow", Toast.LENGTH_SHORT).show();
		
		
          
	/*	
        mItems = new ArrayList<>(30);
        for (int i = 0; i < 30; i++) {
            mItems.add(String.format("Card number %02d", i));
        }*/

        


    }

    
    
    private void cardviewSetToRecycler()
    {
    	//size of fbuserName getting it from server;
    	
	 	int forLoopLength= fbUserName.size();
		Log.e("","For "+forLoopLength);
		mItems = new ArrayList<>(fbUserName.size());
		  for(int i=0;i<forLoopLength;i++)
		  {
			  mItems.add(String.format(fbUserName.get(i),i));
		  }
		  
		  
    	OnItemTouchListener itemTouchListener = new OnItemTouchListener() {
            @Override
            public void onCardViewTap(View view, int position) {
                Toast.makeText(RecievedFriendRequest.this, "Tapped " + mItems.get(position), Toast.LENGTH_SHORT).show();
                
                
               
                
            }

            @Override
            public void onbtnAddFriendClick(View view, int position) {
                Toast.makeText(RecievedFriendRequest.this, "Clicked btnAddFriend in " + mItems.get(position), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onbtnRejectFriendClick(View view, int position) {
                Toast.makeText(RecievedFriendRequest.this, "Clicked btnRejectFriend in " + mItems.get(position), Toast.LENGTH_SHORT).show();
            }
        };
        mAdapter = new CardViewAdapter(mItems, itemTouchListener);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view_friendReq);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(mAdapter);

        SwipeableRecyclerViewTouchListener swipeTouchListener =
                new SwipeableRecyclerViewTouchListener(recyclerView,
                        new SwipeableRecyclerViewTouchListener.SwipeListener() {
                            @Override
                            public boolean canSwipe(int position) {
                                return true;
                            }

                            @Override
                            public void onDismissedBySwipeLeft(RecyclerView recyclerView, int[] reverseSortedPositions) {
                                
                            	
                            	String passPos=null;
                            	String st="1";
                            	for (int position : reverseSortedPositions) {
                                    Toast.makeText(getApplicationContext(), "LEft Swipe ", Toast.LENGTH_SHORT).show();
                  
                                    passPos=mitIdArrayList.get(position);
                                    sendAddRejectFriend(passPos,st);
                                        
                                    mitIdArrayList.remove(position);
                                    fbUserId.remove(position);
                                	fbUserName.remove(position);
                                    mItems.remove(position);
                                    mAdapter.notifyItemRemoved(position);
                            
                                    Log.e("","Position "+position);
                             }
                                
                            	
                             mAdapter.notifyDataSetChanged();
                            }

                            @Override
                            public void onDismissedBySwipeRight(RecyclerView recyclerView, int[] reverseSortedPositions) {
                               
                            	
                            	String passPos=null;
                            	String st="0";
                            	for (int position : reverseSortedPositions) {
                                
                                	passPos=mitIdArrayList.get(position);
                                    sendAddRejectFriend(passPos,st);
                                    mitIdArrayList.remove(position);
                                    fbUserId.remove(position);
                                	fbUserName.remove(position);
                                	Toast.makeText(getApplicationContext(), "Right Swipe ", Toast.LENGTH_SHORT).show();
                                	mItems.remove(position);
                                    mAdapter.notifyItemRemoved(position);
                                }
                                mAdapter.notifyDataSetChanged();
                            }
                        });

        recyclerView.addOnItemTouchListener(swipeTouchListener);
    	
    }
    
    
    
    
    
    
    
    
    
    
  
    
    
    /**
     * Interface for the touch events in each item
     */
    public interface OnItemTouchListener {
        /**
         * Callback invoked when the user Taps one of the RecyclerView items
         *
         * @param view     the CardView touched
         * @param position the index of the item touched in the RecyclerView
         */
        public void onCardViewTap(View view, int position);

        /**
         * Callback invoked when the btnAddFriend of an item is touched
         *
         * @param view     the Button touched
         * @param position the index of the item touched in the RecyclerView
         */
        public void onbtnAddFriendClick(View view, int position);

        /**
         * Callback invoked when the btnRejectFriend of an item is touched
         *
         * @param view     the Button touched
         * @param position the index of the item touched in the RecyclerView
         */
        public void onbtnRejectFriendClick(View view, int position);
    }

    /**
     * A simple adapter that loads a CardView layout with one TextView and two Buttons, and
     * listens to clicks on the Buttons or on the CardView
     */
    public class CardViewAdapter extends RecyclerView.Adapter<CardViewAdapter.ViewHolder> {
        private List<String> cards;
        private OnItemTouchListener onItemTouchListener;

        public CardViewAdapter(List<String> cards, OnItemTouchListener onItemTouchListener) {
            this.cards = cards;
            this.onItemTouchListener = onItemTouchListener;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_view_layout, viewGroup, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            viewHolder.title.setText(cards.get(i));
            
        	for(int j=0;j<fbUserId.size();j++)
          	{	 
          		String profileImgUrl = "https://graph.facebook.com/" + fbUserId.get(i)+ "/picture?type=large";
          		Log.e("","Profile "+fbUserId.get(i));
          		Glide.with(RecievedFriendRequest.this)
          		.load(profileImgUrl)
          		.into(viewHolder.imgFriend);
          	}
        }

        @Override
        public int getItemCount() {
            return cards == null ? 0 : cards.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
       
            private TextView title;
            private CardView cardView;
            //private Button btnAddFriend;
            //private Button btnRejectFriend;
            private ImageView imgFriend;
           
             
            public ViewHolder(View itemView) {
            	
                super(itemView);
             	imgFriend 				=	(ImageView) itemView.findViewById(R.id.imgMyFriend);
                title 							= 	(TextView) itemView.findViewById(R.id.card_view_title);
                cardView				=(CardView)itemView.findViewById(R.id.cv);
                
            //    txtAdd						=	(TextView)itemView.findViewById(R.id.txtadd);
              /*  btnAddFriend 		= 	(Button) itemView.findViewById(R.id.card_view_button1);
                btnRejectFriend = 	(Button) itemView.findViewById(R.id.card_view_button2);

                btnAddFriend.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onItemTouchListener.onbtnAddFriendClick(v, getPosition());
                    }
                });

                btnRejectFriend.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onItemTouchListener.onbtnRejectFriendClick(v, getPosition());
                    }
                });
*/
                
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onItemTouchListener.onCardViewTap(v, getPosition());
                        
                    }
                });
             
                
            }
        }
        
      
        
    }

    private void sendAddRejectFriend(String mMitId,String st){
    	String getMitId=mMitId;
    	String getSt =st;
    	
    	par.put("userOne", getMitId);
    	par.put("userSecond", showMitID);
    	par.put("status", st);
    	
    	//Log.e("","paaa "+getMitId+" how "+showMitID);
    	Toast.makeText(getApplicationContext(), getMitId+"  "+showMitID, Toast.LENGTH_SHORT).show();
    	AsyncHttpClient client = new AsyncHttpClient();
        client.post(NetworkIp.ACCEPT_FRIEND, par,
                new AsyncHttpResponseHandler() {
                    // When the response returned by REST has Http
                    // response code '200'
                    @Override
                    public void onSuccess(String response) {
                        // Hide Progress Dialog
                    	  
                 	   Log.e("","response "+response);
                   	
                    	 try {
                    	   JSONObject mainJson 	= 	new JSONObject(response);
                    	   JSONArray jsonArray		= 	mainJson.getJSONArray("data");
                    	   Log.e("Point","Yes 2");
                    	   JSONObject objJson 	= new JSONObject(response); 
                    	   Log.e("Point","Check 1");
                    	  String success 				= null;
                    	  
                    	  Log.e("Point","Check 2" +jsonArray.length());
                          for (int i 	= 0; i < jsonArray.length(); i++) {
                               	objJson = jsonArray.getJSONObject(i);
                               	success	= 	objJson.getString("success");
                          	Toast.makeText(getApplicationContext(), "Success Val "+success, Toast.LENGTH_LONG).show();
                          } 
                      
                /*          try{
                        	  cardviewSetToRecycler();
                          }catch(Exception e)
                          {
                        	  e.printStackTrace();
                          }
                */
                          
                  		
                     
                         }catch(Exception e)
                         {
                        	 Log.e("",""+e.toString());
                        	 }
                    	 //Toast.makeText(getApplicationContext(), " EXCEPTION", Toast.LENGTH_LONG).show();
                    }

                    // When the response returned by REST has Http
                    // response code other than '200' such as '404',
                    // '500' or '403' etc
                    @Override
                    public void onFailure(int statusCode, Throwable error,
                            String content) {
                        // Hide Progress Dialog
                      
                        // When Http response code is '404'
                        if (statusCode == 404) {
                            Toast.makeText(getApplicationContext(),
                                    "Requested resource not found",
                                Toast.LENGTH_LONG).show();
                        }
                        // When Http response code is '500'
                        else if (statusCode == 500) {
                            Toast.makeText(getApplicationContext(),
                                    "Something went wrong at server end",
                                    Toast.LENGTH_LONG).show();
                        }
                        // When Http response code other than 404, 500
                        else {
                            Toast.makeText(
                                    getApplicationContext(),
                                    "Unexpected Error occcured! [Most common Error: Device might "
                                            + "not be connected to Internet or remote server is not up and running], check for other errors as well",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });	
    	
    }
    
    
    
    
    
public void sendMitId()
{
	String st="2";
	params.put("parseMitId", showMitID);
	Log.e("","Show Mit ID"+showMitID);
	params.put("parseStatus",st );
	Log.e("","exe");	
	AsyncHttpClient client = new AsyncHttpClient();
    client.post(NetworkIp.RECIEVED_FRIEND, params,
            new AsyncHttpResponseHandler() {
                // When the response returned by REST has Http
                // response code '200'
                @Override
                public void onSuccess(String response) {
                    // Hide Progress Dialog
                	  
             	   Log.e("","response "+response);
               	
                	 try {
                	   JSONObject mainJson 	= 	new JSONObject(response);
                	   JSONArray jsonArray		= 	mainJson.getJSONArray("data");
                	   Log.e("Point","Yes 2");
                	   
                	   JSONObject objJson 	= new JSONObject(response); 
                	   Log.e("Point","Check 1");
                	   
                	  String success 				= null;
                      String  name					=	null;
                      String fbId						=	null;
                      String mitId						= null;
                      Log.e("Point","Check 2");
               	   //arraylist clear
                      //fbUserId.clear();
                      //fbUserName.clear();
                      fbUserName.clear();
                      fbUserId.clear();
                      mitIdArrayList.clear();
                      Log.e("Point","Check 3" +jsonArray.length());
                      
               	   
                      for (int i 	= 0; i < jsonArray.length(); i++) {
                           	objJson = jsonArray.getJSONObject(i);
                           	//success	= 	objJson.getString("success");
                      	 	name			=	objJson.getString("user_name");
                      	 	fbId				=	objJson.getString("facebook_id");
                      	 	mitId				= objJson.getString("mitrano_user_id");
                      	 //   Toast.makeText(getApplicationContext(), "USerName "+name, Toast.LENGTH_LONG).show();
                         
                      	    //adding in arraylist 
                      	    fbUserName.add(name);
                            fbUserId.add(fbId);
                            mitIdArrayList.add(mitId);
                       } 
                      
                      Toast.makeText(getApplicationContext(), "Sizee"+fbUserId.size()+"\n"+fbUserName.size()+"\n"+mitIdArrayList.size(), Toast.LENGTH_LONG).show();
                      
                      Log.e("","FB NAME "+mitIdArrayList);
                      
                      try{
                    	  cardviewSetToRecycler();
                      }catch(Exception e)
                      {
                    	  e.printStackTrace();
                      }
            
                      
              		
                 
                     }catch(Exception e)
                     {
                    	 Log.e("",""+e.toString());
                    	 }
                	 //Toast.makeText(getApplicationContext(), " EXCEPTION", Toast.LENGTH_LONG).show();
                }

                // When the response returned by REST has Http
                // response code other than '200' such as '404',
                // '500' or '403' etc
                @Override
                public void onFailure(int statusCode, Throwable error,
                        String content) {
                    // Hide Progress Dialog
                  
                    // When Http response code is '404'
                    if (statusCode == 404) {
                        Toast.makeText(getApplicationContext(),
                                "Requested resource not found",
                            Toast.LENGTH_LONG).show();
                    }
                    // When Http response code is '500'
                    else if (statusCode == 500) {
                        Toast.makeText(getApplicationContext(),
                                "Something went wrong at server end",
                                Toast.LENGTH_LONG).show();
                    }
                    // When Http response code other than 404, 500
                    else {
                        Toast.makeText(
                                getApplicationContext(),
                                "Unexpected Error occcured! [Most common Error: Device might "
                                        + "not be connected to Internet or remote server is not up and running], check for other errors as well",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });	
}

@Override
public boolean onCreateOptionsMenu(Menu menu) {
	// Inflate the menu; this adds items to the action bar if it is present.
	getMenuInflater().inflate(R.menu.menu_refresh, menu);
	return super.onCreateOptionsMenu(menu);
}

@Override
public boolean onOptionsItemSelected(MenuItem item) {
	// Handle action bar item clicks here. The action bar will
	// automatically handle clicks on the Home/Up button, so long
	// as you specify a parent activity in AndroidManifest.xml.
	int id = item.getItemId();
	if (id == R.id.refresh) {
	    try{
      	  cardviewSetToRecycler();
        }catch(Exception e)
        {
      	  e.printStackTrace();
        }
		return true;
	}

	return super.onOptionsItemSelected(item);
}

};

/*public class RecievedFriendRequest extends Activity{
RequestParams params;
String showMitID =null;
private ProgressDialog showProgress;
RecyclerView mRecyclerView;
RecyclerView.LayoutManager mLayoutManager;
RecyclerView.Adapter mAdapter;


String[] dataArray;
String friendId;
String fbID;
String profileImgUrl;

@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.friend_request_received);
		params = new RequestParams(); 
	
		
		DBHandler dbh= new DBHandler(getApplicationContext());
		Cursor cursor = dbh.readMitId(dbh);
		
		while(cursor.moveToNext()){
			 showMitID 	= cursor.getString(0);
			 Log.e("","MITID DISPLAYED "+showMitID);
		    // Log.e("","GDT "+google_distance_time+" wait "+wait_time);
		 }
		cursor.close(); 	
	//	sendMitId();
		Toast.makeText(getApplicationContext(), "Wow", Toast.LENGTH_SHORT).show();
		


}
*/