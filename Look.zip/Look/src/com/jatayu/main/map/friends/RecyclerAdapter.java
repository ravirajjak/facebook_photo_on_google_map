package com.jatayu.main.map.friends;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bumptech.glide.Glide;
import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.sqlite.DBHandler;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
* Created by rajat on 2/8/2015.
*/
public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
   private String[] dataSource;
   private Context passContext;
   private String FID;
   private RequestParams params;
   public RecyclerAdapter(String[] dataArgs,Context ctx,String parseFID){
       dataSource 	= dataArgs;
       passContext	= ctx;
       FID						= parseFID;
   }
   @Override
   public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       // create a new view
       View view = LayoutInflater.from(parent.getContext())
               .inflate(R.layout.populate_friends_item, parent, false);
       params= new RequestParams();
       ViewHolder viewHolder = new ViewHolder(view);
       return viewHolder;


   }

   @Override
   public void onBindViewHolder(final ViewHolder holder, int position) {
       holder.textView.setText(dataSource[position]);
       
       Log.e("","WOw");
       String profileImgUrl = "https://graph.facebook.com/" + FID + "/picture?type=large";
       Glide.with(passContext)
                  .load(profileImgUrl)
                  .into(holder.profilePicFb);
       Log.e("","GLidedd");
	  holder.btnAdd.setOnClickListener(new OnClickListener() {
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Toast.makeText(passContext, "IT worked", Toast.LENGTH_LONG).show();
			sendFriendRequest();
		}
	});
   }
private void sendFriendRequest() {
	AsyncHttpClient client = new AsyncHttpClient();
	
	//SharedPreferences sharedPref 	= 	passContext.getSharedPreferences("Jatayu_User_Detail", Context.MODE_PRIVATE);

	//String currentUserId			=	sharedPref.getString("mit_user_id", "");
	DBHandler dbh= new DBHandler(passContext);
	String senderId = null;
	Cursor cursor = dbh.readAllRow(dbh);
	while(cursor.moveToNext()){
		senderId 	= cursor.getString(0);
	}
	cursor.close(); 

	String mitOtherId		=		SearchFriends.mitOtherFrndID;
	params.put("parseFirstUserID", senderId);
	params.put("parseSecondUserID", mitOtherId);
	
	Log.e("","YES !!!"+ params);
    client.post(NetworkIp.SEND_FRIEND_REQUEST_URL, params,
            new AsyncHttpResponseHandler() {
                // When the response returned by REST has Http
                // response code '200'
                @Override
                public void onSuccess(String response) {
                    // Hide Progress Dialog
                	
                	//   Toast.makeText(passContext, "Success Saev", Toast.LENGTH_LONG).show();
                	 try
                     {
                	   JSONObject mainJson 	= 	new JSONObject(response);
                	   JSONArray jsonArray	= 	mainJson.getJSONArray("data");
                       Log.e("Point","Yes 2");
                       JSONObject objJson = new JSONObject(response);
                       Log.e("","Respo" +response) ;
                       String success = null;
                        
                       // ArrayList<String> userNameAL = new ArrayList<String>();
                       for (int i 	= 0; i < jsonArray.length(); i++) {
                           objJson 		= jsonArray.getJSONObject(i);
                           success			= 	objJson.getString("success");
                           if(success.equals("1")){
                        	   Toast.makeText(passContext, "Friend Request Sent", Toast.LENGTH_SHORT).show();
                           }
                           if(success.equals("0")){
                        	   Toast.makeText(passContext, "Something went wrong", Toast.LENGTH_SHORT).show();
                           }
                       }
                       }catch(Exception e)
                     {e.printStackTrace();}

                }   			 
    	
                

                // When the response returned by REST has Http
                // response code other than '200' such as '404',
                // '500' or '403' etc
                @Override
                public void onFailure(int statusCode, Throwable error,String content) {
                    // Hide Progress Dialog
                    // When Http response code is '404'
                    if (statusCode == 404) {
                        Toast.makeText(passContext,
                                "Requested resource not found",
                                Toast.LENGTH_LONG).show();
                    }
                    // When Http response code is '500'
                    else if (statusCode == 500) {
                        Toast.makeText(passContext,
                                "Something went wrong at server end",
                                Toast.LENGTH_LONG).show();
                    }
                    // When Http response code other than 404, 500
                    else {
                        Toast.makeText(
                        		passContext,
                                "Unexpected Error occcured! [Most common Error: Device might "
                                        + "not be connected to Internet or remote server is not up and running], check for other errors as well",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });
}
   @Override
   public int getItemCount() {
       return dataSource.length;
   }

   public static class ViewHolder extends RecyclerView.ViewHolder{
       protected TextView textView;
       protected ImageView profilePicFb ;
       protected Button btnAdd;
       protected Button btnReject;
       
       public ViewHolder(View itemView) {
       super(itemView);
           textView 	=  (TextView) itemView.findViewById(R.id.tvFriendName);
           profilePicFb	=	(ImageView)itemView.findViewById(R.id.friends_img);
           btnAdd		=	(Button)itemView.findViewById(R.id.btnAddFriend);
           btnReject	=	(Button)itemView.findViewById(R.id.btnRejectFriend);
           
       }
   }
}