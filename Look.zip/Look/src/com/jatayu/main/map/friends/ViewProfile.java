package com.jatayu.main.map.friends;


import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.navigation.RoundImage;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewProfile extends ActionBarActivity {
		TextView tvStatus;
		ImageView imgFriend;
		GoogleMap googleMap;
		Toolbar mToolbar;
		
		String facebookID,mitID,facebookUserName,userStatus,userDateTime;
		LatLng setLatLng;
		//getSupportActionBar().setDisplayShowHomeEnabled(true);
//		getSupportActionBar().setHomeButtonEnabled(true);


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_profile);
        mToolbar = (Toolbar) findViewById(R.id.toolbar_trans);
        setSupportActionBar(mToolbar); 
        tvStatus= (TextView) findViewById(R.id.tvValueStatus);
        
        Intent iin= getIntent();
        Bundle b = iin.getExtras();

        if(b!=null)
        {
            facebookID					=(String)b.get("facebook_id");
            facebookUserName	=(String)b.get("facebook_username");
            mitID								=(String)b.get("mitrano_id");
            userStatus						=(String)b.get("status");
            userDateTime				=(String)b.get("set_time")+" "+(String)b.get("set_date");
            tvStatus.setText(userStatus);
        }
        initilizeMap();		
        getSupportActionBar().setTitle(facebookUserName);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		imgFriend =(ImageView) findViewById(R.id.imgFriendViewProfile);
		String profileImgUrl = "https://graph.facebook.com/"+facebookID+"/picture?type=large";
		
  		Glide.with(ViewProfile.this)
  		.load(profileImgUrl)
  		.into(imgFriend);

        setLatLng						= new LatLng(Double.parseDouble((String) b.get("latitude")),Double.parseDouble((String) b.get("longitude")));
        googleMap.addMarker(new MarkerOptions().title(userStatus).snippet(userDateTime).position(setLatLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(setLatLng));
	}  		
	@Override
	    protected void onResume() {
	        super.onResume();
	        initilizeMap();
	    } 
	
	private void initilizeMap() {
  	        if (googleMap == null) {
  	            googleMap = ((MapFragment) getFragmentManager().findFragmentById(
  	                    R.id.mapFrag)).getMap();
  	 
  	            // check if map is created successfully or not
  	            if (googleMap == null) {
  	                Toast.makeText(getApplicationContext(),
  	                        "Sorry! unable to create maps", Toast.LENGTH_SHORT)
  	                        .show();
  	            }
  	        }
		}
	}