package com.jatayu.main.map.friends;



import org.json.JSONArray;
import org.json.JSONObject;

import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.look.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class SearchFriends extends Activity{
	EditText edtFriendsSearch ;
	ImageButton imgBtnSearch;
	RequestParams params;
	
	private ProgressDialog showProgress;
	private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    
    String[] dataArray;
    String friendId;
    String fbID;
    String profileImgUrl;
    public static String mitOtherFrndID;
    
    ImageView facebookImage;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search_friends);
		
		
		facebookImage			=	(ImageView)		findViewById(R.id.friends_img);
		edtFriendsSearch		=	(EditText)			 	findViewById(R.id.edtSearch);
		
		recyclerView 				= 	(RecyclerView)	findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager 		= 	new LinearLayoutManager(this);
        
        params 						=	new RequestParams();
 
        showProgress			=	new ProgressDialog(SearchFriends.this);
        recyclerView.setLayoutManager(layoutManager);
		
        
        
        imgBtnSearch		=	(ImageButton)findViewById(R.id.btnSearch);
		imgBtnSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				friendId= edtFriendsSearch.getText().toString();
				params.put("friend_id", friendId);
				showProgress.setMessage("Searching ...");
				showProgress.show();
				requestFriendSearch();
				
			}
		});
	}
	
	
	private void requestFriendSearch() {
		
		final SharedPreferences prefs = getSharedPreferences("Jatayu_User_Detail",
                Context.MODE_PRIVATE);
    	
    	String mitID	= 	prefs.getString("mit_user_id","");
    	Log.e("id","id "+mitID+" f id "+friendId );
		if(friendId != null)
		{
			if(mitID.equals(friendId)){
				Toast.makeText(getApplicationContext(), "Dont search yourself Buddy, Find your MITRANO", Toast.LENGTH_LONG).show();
				if(showProgress.isShowing()){
       			 showProgress.dismiss();
       		 }
			}
			else
			{
				
				AsyncHttpClient client = new AsyncHttpClient();
				Log.e("","YES !!!");
			    client.post(NetworkIp.FRIEND_REQUEST_URL, params,
			            new AsyncHttpResponseHandler() {
			                // When the response returned by REST has Http
			                // response code '200'
			                @Override
			                public void onSuccess(String response) {
			                    // Hide Progress Dialog
			                	Log.e("","Response "+response);
			                	//   Toast.makeText(getApplicationContext(), "Success Saev", Toast.LENGTH_LONG).show();
			                	 try{
			                	   JSONObject mainJson 	= 	new JSONObject(response);
			                	   JSONArray jsonArray	= 	mainJson.getJSONArray("data");
			                       Log.e("Point","Yes 2");
			                       JSONObject objJson = new JSONObject(response);
			                       Log.e("","Respo" +response) ;
			                       String success = null;
			                        
			                       // ArrayList<String> userNameAL = new ArrayList<String>();
			                       for (int i 	= 0; i < jsonArray.length(); i++) {
			                           objJson = jsonArray.getJSONObject(i);
			                           success			= 	objJson.getString("success");
			                           String userName	= 	objJson.getString("user_name");
			                           fbID				=	objJson.getString("facebook_id");
			                           mitOtherFrndID	=	objJson.getString("mit_user_id");
			                           Log.e("","qqqqqqqqqqq");
			                           
			                           dataArray= new String[]{userName};
			                           Toast.makeText(getApplicationContext(), "USerName "+userName, Toast.LENGTH_LONG).show();
			                       }
			                      
			                        	adapter = new RecyclerAdapter(dataArray,getApplicationContext(),fbID);
			 	                       	recyclerView.setAdapter(adapter);
			 	                    
			 	                       	
			 	                    
			                           
			                        
			                       }catch(Exception e)
			                     {e.printStackTrace();}

		                		 if(showProgress.isShowing()){
		                			 showProgress.dismiss();
		                		 }
			                }   			 
			    	
			                

			                // When the response returned by REST has Http
			                // response code other than '200' such as '404',
			                // '500' or '403' etc
			                @Override
			                public void onFailure(int statusCode, Throwable error,String content) {
			                    // Hide Progress Dialog
			                	if(showProgress.isShowing())
		               		 		{
		               			 		showProgress.dismiss();
		               		 		}
			                    // When Http response code is '404'
			                    if (statusCode == 404) {
			                        Toast.makeText(getApplicationContext(),
			                                "Requested resource not found",
			                                Toast.LENGTH_LONG).show();
			                    }
			                    // When Http response code is '500'
			                    else if (statusCode == 500) {
			                        Toast.makeText(getApplicationContext(),
			                                "Something went wrong at server end",
			                                Toast.LENGTH_LONG).show();
			                    }
			                    // When Http response code other than 404, 500
			                    else {
			                        Toast.makeText(
			                                getApplicationContext(),
			                                "Unexpected Error occcured! [Most common Error: Device might "
			                                        + "not be connected to Internet or remote server is not up and running], check for other errors as well",
			                                Toast.LENGTH_LONG).show();
			                    }
			                }
			            });
			}
		}else{
		// TODO Auto-generated method stub
			Toast.makeText(getApplicationContext(), "ERROR Buddy!!", Toast.LENGTH_LONG).show();
			
			}	
		}
	}
