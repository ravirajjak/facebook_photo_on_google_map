
package com.jatayu.main.map.navigation;

/**
 * Created by poliveira on 27/10/2014.
 */
public interface NavigationDrawerCallbacks {
    void onNavigationDrawerItemSelected(int position);
}
