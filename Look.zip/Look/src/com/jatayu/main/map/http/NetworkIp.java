package com.jatayu.main.map.http;

/**
 * Created by ravi on 04-08-2015.
 */
public class NetworkIp {
    

    public static final String REGISTER_URL									=	"http://mitranno.com/mitrano/fbgatepass.php";
    public static final String FRIEND_REQUEST_URL					=	"http://mitranno.com/mitrano/search_friend.php";
    public static final String SEND_FRIEND_REQUEST_URL	=	"http://mitranno.com/mitrano/friend_request.php";
    public static final String RECIEVED_FRIEND							=	"http://mitranno.com/mitrano/friend_list.php";
    public static final String ACCEPT_FRIEND								=	"http://mitranno.com/mitrano/accept_friend.php";
    public static final String MY_FRIEND											=	"http://mitranno.com/mitrano/my_friends.php";
    public static final String DISPLAY_FRIENDS							=	"http://mitranno.com/mitrano/first_page_load.php";
    public static final String INSERT_LOCATION							=	"http://mitranno.com/mitrano/insert_location.php";
}