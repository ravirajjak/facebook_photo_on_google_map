package com.jatayu.main.map.look;

public class Tab3Adapter {
public String fbName,fbId,mitrannoId,latitude,longitude,uStatus,uSetTime,uSetDate;

public String getFbName() {
	return fbName;
}

public void setFbName(String fbName) {
	this.fbName = fbName;
}

public String getFbId() {
	return fbId;
}

public void setFbId(String fbId) {
	this.fbId = fbId;
}

public String getMitrannoId() {
	return mitrannoId;
}

public void setMitrannoId(String mitrannoId) {
	this.mitrannoId = mitrannoId;
}

public String getLatitude() {
	return latitude;
}

public void setLatitude(String latitude) {
	this.latitude = latitude;
}

public String getLongitude() {
	return longitude;
}

public void setLongitude(String longitude) {
	this.longitude = longitude;
}

public String getuStatus() {
	return uStatus;
}

public void setuStatus(String uStatus) {
	this.uStatus = uStatus;
}

public String getuSetTime() {
	return uSetTime;
}

public void setuSetTime(String uSetTime) {
	this.uSetTime = uSetTime;
}

public String getuSetDate() {
	return uSetDate;
}

public void setuSetDate(String uSetDate) {
	this.uSetDate = uSetDate;
}

}
