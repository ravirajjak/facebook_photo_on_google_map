package com.jatayu.main.map.look;

import java.util.List;

import com.bumptech.glide.Glide;
import com.jatayu.main.map.glideutils.GlideCircleTransform;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListViewDemoAdapter extends ArrayAdapter<ListViewItem> {
	 
    public ListViewDemoAdapter(Context context, List<ListViewItem> items) {
        super(context, R.layout.mylist, items);
    }
 
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        
        if(convertView == null) {
            // inflate the GridView item layout
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.mylist, parent, false);
            
            // initialize the view holder
            viewHolder = new ViewHolder();
            viewHolder.ivIcon = (ImageView) convertView.findViewById(R.id.ivIcon);
            viewHolder.tvTitle = (TextView) convertView.findViewById(R.id.tvTitle);
            viewHolder.tvDescription = (TextView) convertView.findViewById(R.id.tvDescription);
            viewHolder.tvDateTime = (TextView) convertView.findViewById(R.id.tvDateTime);
            
            convertView.setTag(viewHolder);
        } else {
            // recycle the already inflated view 
            viewHolder = (ViewHolder) convertView.getTag();
        }
        
        // update the item view
        ListViewItem item = getItem(position);
        Glide.with(getContext())
        .load(item.pic_url)
        .transform(new GlideCircleTransform(getContext()))
        
        .into(viewHolder.ivIcon);
        
        //viewHolder.ivIcon.setImageDrawable(item.icon);
        viewHolder.tvTitle.setText(item.username);
        viewHolder.tvDescription.setText(item.status);
        viewHolder.tvDateTime.setText(item.datetime);
        
        return convertView;
    }
    
    /**
     * The view holder design pattern prevents using findViewById()
     * repeatedly in the getView() method of the adapter.
     * 
     * @see http://developer.android.com/training/improving-layouts/smooth-scrolling.html#ViewHolder
     */
    private static class ViewHolder {
        ImageView ivIcon;
        TextView tvTitle;
        TextView tvDescription;
        TextView tvDateTime;
        
    }
}