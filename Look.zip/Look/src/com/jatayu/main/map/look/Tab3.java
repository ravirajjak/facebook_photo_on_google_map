package com.jatayu.main.map.look;


import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bumptech.glide.Glide;
import com.jatayu.main.map.glideutils.GlideCircleTransform;
import com.jatayu.main.map.gpstracker.ConnectionDetector;
import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.navigation.NavigationDrawerFragment;
import com.jatayu.main.map.sqlite.DBHandler;
import com.jatayu.main.map.sqlite.PassKey.TableInfo;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;


public class Tab3 extends android.support.v4.app.ListFragment {
	 private List<ListViewItem> mItems;        // ListView items list
	 
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        
	        // initialize the items list
	        mItems = new ArrayList<ListViewItem>();
	        ListViewItem lvi ;
			
	        DBHandler dbh = new DBHandler(getContext());
	        String friend_name, friend_status,friend_date_time,friend_fb_id;
	        String fb_url;
	        Cursor cursor = dbh.readAllFriends(dbh);
			while(cursor.moveToNext()){
				friend_name 				= cursor.getString(cursor.getColumnIndex(TableInfo.F_USER_NAME));
				friend_status			=	cursor.getString(cursor.getColumnIndex(TableInfo.F_USER_STATUS));
				friend_date_time	=	cursor.getString(cursor.getColumnIndex(TableInfo.F_DATE));
				friend_fb_id				=	cursor.getString(cursor.getColumnIndex(TableInfo.F_FACEBOOK_ID));
				fb_url="https://graph.facebook.com/"+friend_fb_id+"/picture?type=large";
				lvi= new ListViewItem(fb_url, friend_name, friend_status, friend_date_time);
				mItems.add(lvi);
			}
			cursor.close(); 
			// initialize and set the list adapter
	        setListAdapter(new ListViewDemoAdapter(getActivity(), mItems));
	    }
	    
	    @Override
	    public void onViewCreated(View view, Bundle savedInstanceState) {
	        super.onViewCreated(view, savedInstanceState);
	        // remove the dividers from the ListView of the ListFragment
	        getListView().setDivider(null);
	    }
	 
	    @Override
	    public void onListItemClick(ListView l, View v, int position, long id) {
	        // retrieve theListView item
	        ListViewItem item = mItems.get(position);
	        
	        // do something
	        Toast.makeText(getActivity(), item.username, Toast.LENGTH_SHORT).show();
	    }    
}