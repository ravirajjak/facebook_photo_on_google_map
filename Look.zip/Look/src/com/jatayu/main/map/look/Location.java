package com.jatayu.main.map.look;

import java.util.concurrent.ExecutionException;

import org.json.JSONArray;
import org.json.JSONObject;

import com.jatayu.main.map.gpstracker.GPSTracker;
import com.jatayu.main.map.http.NetworkIp;
import com.jatayu.main.map.sqlite.DBHandler;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AlertDialog;


import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;




















public class Location extends Activity {
	RequestParams params;
	@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.location);
			 final RippleBackground rippleBackground=(RippleBackground)findViewById(R.id.content);
			 	params =new RequestParams();
		        final Handler handler=new Handler();
            	final LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            	ImageView button=(ImageView)findViewById(R.id.centerImage);
            	
		        button.setOnClickListener(new View.OnClickListener() {
		            @Override
		            public void onClick(View view) {
		            		if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
		            			rippleBackground.startRippleAnimation();
		            	      	String mitId=  	getUserMitId();
		            	      	
		                    	Log.e(""," MIT ID "+mitId);
		                    	updateUserLocation(mitId);
		            	/*		handler.postDelayed(new Runnable() {
    		                    @Override
    		                    public void run() {
    		              
    		                    }
    		                },30000);
*/
                        }else{
                            showGPSDisabledAlertToUser();
                        	}

		            }
		        });
		    }

	
	
	private String  getUserMitId()
	{
		DBHandler dbh = new DBHandler(getApplicationContext());
        String showMitID=null;
        
        Cursor cursor = dbh.readAllRow(dbh);
		while(cursor.moveToNext()){
			 showMitID 	= cursor.getString(0);
			 Log.e("","MITID DISPLAYED "+showMitID);
		    // Log.e("","GDT "+google_distance_time+" wait "+wait_time);
		 }
		cursor.close(); 
		return showMitID;
		
	}
	
	private void updateUserLocation(String showMitID)
	{
		GPSTracker gps= new GPSTracker(getApplicationContext());
        double lat=gps.getLatitude();
        double lng=gps.getLongitude();

    	AsyncHttpClient client = new AsyncHttpClient();
		Log.e("","YES !!!");
		params.put("parseMitID", showMitID);
		params.put("parseLatitude", String.valueOf(lat));
		params.put("parseLongitude", String.valueOf(lng));
		Log.e("","LAt "+lat+" Lng "+lng);
		client.post(NetworkIp.INSERT_LOCATION, params,
	            new AsyncHttpResponseHandler() {
	                // When the response returned by REST has Http
	                // response code '200'
	                @Override
	                public void onSuccess(String response) {
	                    // Hide Progress Dialog
	                	Log.e("","Response "+response);
	                	//   Toast.makeText(getApplicationContext(), "Success Saev", Toast.LENGTH_LONG).show();
	                	 try{
	                	   
	                		JSONObject mainJson 	= 	new JSONObject(response);
	                	   JSONArray jsonArray		= 	mainJson.getJSONArray("data");
	                       Log.e("Point","Yes 2");
	                       JSONObject objJson = new JSONObject(response);
	                       
	                       for (int i 	= 0; i < jsonArray.length(); i++) {
           					objJson = jsonArray.getJSONObject(i);
           					String success =objJson.getString("success");
           					if(success.equals("1")){
           						Intent act= new Intent(Location.this,ContainerTab.class);
           						startActivity(act);
           						finish();
           					}
           					else
           					{
           						Toast.makeText(getApplicationContext(), "Location not updated", Toast.LENGTH_SHORT).show();
           					}
	                       }
	                       }
	                         catch(Exception e)
	                     {e.printStackTrace();}
	                }   			 
	    	
	        


					// When the response returned by REST has Http
	                // response code other than '200' such as '404',
	                // '500' or '403' etc
	                @Override
	                public void onFailure(int statusCode, Throwable error,String content) {
	                    if (statusCode == 404) {
	                        Toast.makeText(getApplicationContext(),
	                                "Requested resource not found",
	                                Toast.LENGTH_LONG).show();
	                    }
	                    // When Http response code is '500'
	                    else if (statusCode == 500) {
	                        Toast.makeText(getApplicationContext(),
	                                "Something went wrong at server end",
	                                Toast.LENGTH_LONG).show();
	                    }
	                    // When Http response code other than 404, 500
	                    else {
	                        Toast.makeText(
	                                getApplicationContext(),
	                                "Unexpected Error occcured! [Most common Error: Device might "
	                                        + "not be connected to Internet or remote server is not up and running], check for other errors as well",
	                                Toast.LENGTH_LONG).show();
	                    }
	                }
	            });

	}
	
private void showGPSDisabledAlertToUser(){
    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
    alertDialogBuilder.setMessage("GPS is disabled in your device. Would you like to enable it?")
    .setCancelable(false)
    .setPositiveButton("Goto Settings Page To Enable GPS",
            new DialogInterface.OnClickListener(){
        public void onClick(DialogInterface dialog, int id){
            Intent callGPSSettingIntent = new Intent(
                    android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(callGPSSettingIntent);
        }
    });
    alertDialogBuilder.setNegativeButton("Cancel",
            new DialogInterface.OnClickListener(){
        public void onClick(DialogInterface dialog, int id){
            dialog.cancel();
        }
    });
    AlertDialog alert = alertDialogBuilder.create();
    alert.show();
}
}
	    /*private void foundDevice(){
		        AnimatorSet animatorSet = new AnimatorSet();
		        animatorSet.setDuration(400);
		        animatorSet.setInterpolator(new AccelerateDecelerateInterpolator());
		        ArrayList<Animator> animatorList=new ArrayList<Animator>();
		        ObjectAnimator scaleXAnimator = ObjectAnimator.ofFloat(foundDevice, "ScaleX", 0f, 1.2f, 1f);
		        animatorList.add(scaleXAnimator);
		        ObjectAnimator scaleYAnimator = ObjectAnimator.ofFloat(foundDevice, "ScaleY", 0f, 1.2f, 1f);
		        animatorList.add(scaleYAnimator);
		        animatorSet.playTogether(animatorList);
		        foundDevice.setVisibility(View.VISIBLE);
		        animatorSet.start();
		    }*/
	

