package com.jatayu.main.map.look;


public class ListViewItem {
    public final String pic_url;       // the drawable for the ListView item ImageView
    public final String username;        // the text for the ListView item title
    public final String status;  // the text for the ListView item description
    public final String datetime;
    
    public ListViewItem(String pic_url, String username, String status,String  datetime) {
        this.pic_url = pic_url;
        this.username = username;
        this.status = status;
        this.datetime = datetime;
        
    }
}