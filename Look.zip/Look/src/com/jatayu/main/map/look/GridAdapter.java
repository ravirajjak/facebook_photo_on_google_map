package com.jatayu.main.map.look;


import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import com.bumptech.glide.Glide;
import com.jatayu.main.map.look.R;

/**
 * Created by Edwin on 28/02/2015.
 */
public class GridAdapter  extends RecyclerView.Adapter<GridAdapter.ViewHolder> {

    List<EndangeredItem> mItems;
    Context activity;

    public GridAdapter(Context ctx) {
        super();
        activity=ctx;
        mItems = new ArrayList<EndangeredItem>();
        EndangeredItem species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);
        
        species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);
        species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);
        species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);
        species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);
        
        species = new EndangeredItem();
        species.setName("Ravi Rajjak");
      //  species.setThumbnail(activity);
        mItems.add(species);

  /*    species = new EndangeredItem();
        species.setName("Black Rhino");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Orangutan");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Sea Lions");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Indian Elephant");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Giant Panda");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Snow Leopard");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);

        species = new EndangeredItem();
        species.setName("Dolphin");
        species.setThumbnail(R.drawable.wallpaper);
        mItems.add(species);*/
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.friend_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        EndangeredItem nature = mItems.get(i);
        viewHolder.tvspecies.setText(nature.getName());
      
			    String profileImgUrl = "https://graph.facebook.com/998365793528829/picture?type=large";
		        Log.e("","PRO ACT "+activity);
		        Glide.with(activity)
		                   .load(profileImgUrl)
		                   .into( viewHolder.imgThumbnail);
    				}

    @Override
    public int getItemCount() {

        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView imgThumbnail;
        public TextView tvspecies;

        public ViewHolder(View itemView) {
            super(itemView);
            imgThumbnail = (ImageView)itemView.findViewById(R.id.img_thumbnail);
            tvspecies = (TextView)itemView.findViewById(R.id.tv_species);
        }
    }
}