package com.jatayu.main.map.look;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.Locale;

/**
 * Created by ravi on 12-07-2015.
 */
public class PagerAdapter extends FragmentPagerAdapter {

    public PagerAdapter(FragmentManager fm) {
        super(fm);
    }


    @Override
    public Fragment getItem(int i) {

        switch (i) {
            case 0:
                Tab1 t1 = new Tab1();
                return t1;
            case 1:
                //Tab2 t2 = new Tab2();
//                return t2;
            case 2:
                Tab3 t3 = new Tab3();
                return t3;
        }
        return null;
    }

    @Override
    public int getCount() {
        return 3;
    }//set the number of tabs

    @Override
    public CharSequence getPageTitle(int position) {
        Locale l = Locale.getDefault();
        switch (position) {
            case 0:
                return "MAP";
            case 1:

                return "PLACES";
            case 2:

                return "MITRA";
        }
        return null;
    }
}
