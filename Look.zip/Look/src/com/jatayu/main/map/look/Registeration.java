package com.jatayu.main.map.look;



import android.app.Activity;
import android.os.Bundle;
import com.jatayu.main.map.look.R;

/**
 * Created by ravi on 26-07-2015.
 */
public class Registeration extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registeration);
    }
}
