package com.jatayu.main.map.look;

import android.content.Context;

public class EndangeredItem {
    private String mName;
    private Context mCtx;

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public Context getThumbnail() {
        return mCtx;
    } 

    public void setThumbnail(Context ctx) {
        this.mCtx = ctx;
    }
}
