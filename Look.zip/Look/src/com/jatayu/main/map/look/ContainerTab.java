package com.jatayu.main.map.look;


import com.jatayu.main.map.friends.RecievedFriendRequest;
import com.jatayu.main.map.friends.SearchFriends;
import com.jatayu.main.map.navigation.NavigationDrawerCallbacks;
import com.jatayu.main.map.navigation.NavigationDrawerFragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class ContainerTab extends AppCompatActivity  implements NavigationDrawerCallbacks {

    // Declaring Your View and Variables

    Toolbar toolbar;
    ViewPager pager;
    ViewPagerAdapter adapterViewPager;
    SlidingTabLayout tabs;
    CharSequence Titles[]={"MAP GUIDE","TRIP"};
    int Numboftabs =2; 

	private NavigationDrawerFragment mNavigationDrawerFragment;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        
        
    	mNavigationDrawerFragment = (NavigationDrawerFragment) getFragmentManager().findFragmentById(R.id.fragment_drawer);
		mNavigationDrawerFragment.setup(R.id.fragment_drawer, (DrawerLayout) findViewById(R.id.drawer), toolbar);

        
        adapterViewPager =  new ViewPagerAdapter(getSupportFragmentManager(),Titles,Numboftabs);
	   // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapterViewPager);

     
        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) findViewById(R.id.tabs);
        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width

        
        // Setting Custom Color for the Scroll bar indicator of the Tab View
        tabs.setCustomTabColorizer(new SlidingTabLayout.TabColorizer() {
        
        	@Override
            public int getIndicatorColor(int position) {
                return getResources().getColor(R.color.whiteColor);
            }
        });
        
        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);
    }
    
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);	
		return super.onCreateOptionsMenu(menu);
	}

    public void onNavigationDrawerItemSelected(int position) {
		Toast.makeText(this, "Menu item selected -> " + position, Toast.LENGTH_SHORT).show();
    }

	@Override
	public void onBackPressed() {
		if (mNavigationDrawerFragment.isDrawerOpen())
			mNavigationDrawerFragment.closeDrawer();
		else
			super.onBackPressed();
		}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		Log.e("","id Inflater "+id);
		Log.e("","R,id "+R.id.shIcon);
		if (id == R.id.shIcon) {
			   		Intent intent = new Intent(this, SearchFriends.class);
					startActivity(intent);
					overridePendingTransition( android.R.anim.fade_in, android.R.anim.fade_out );
			return true;
		}
		if (id == R.id.friend_request) {
	  		Intent intent = new Intent(this,RecievedFriendRequest .class);
	  		Log.e("","EEXE");
			startActivity(intent);
			overridePendingTransition( android.R.anim.fade_in, android.R.anim.fade_out );
	return true;
}
		return super.onOptionsItemSelected(item);
	}

}