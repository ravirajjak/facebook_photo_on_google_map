package com.jatayu.main.map.look;



import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;



import com.jatayu.main.map.friends.RecievedFriendRequest;
//import com.jatayu.main.map.friends.RecievedFriendRequest;
import com.jatayu.main.map.friends.SearchFriends;
import com.jatayu.main.map.look.R;
import com.jatayu.main.map.navigation.NavigationDrawerCallbacks;
import com.jatayu.main.map.navigation.NavigationDrawerFragment;

public class MainActivity extends AppCompatActivity implements NavigationDrawerCallbacks {
	ViewPager pager;
	PagerTabStrip tab_strp;
	private Toolbar mToolbar;
	private NavigationDrawerFragment mNavigationDrawerFragment;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
		setSupportActionBar(mToolbar);
		getSupportActionBar().setDisplayShowHomeEnabled(true);
		//getSupportActionBar().setIcon(R.drawable.vibrate);
/*
		tab_strp=(PagerTabStrip)findViewById(R.id.tab_strip); 
	    tab_strp.setTextColor(Color.WHITE);
	    tab_strp.setTabIndicatorColor(Color.WHITE);
*/
		mNavigationDrawerFragment = (NavigationDrawerFragment) getFragmentManager().findFragmentById(R.id.fragment_drawer);
		mNavigationDrawerFragment.setup(R.id.fragment_drawer, (DrawerLayout) findViewById(R.id.drawer), mToolbar);

		
		PagerAdapter mapager=new PagerAdapter(getSupportFragmentManager());
	    pager=(ViewPager)findViewById(R.id.pager);
	    pager.setAdapter(mapager);
	   


		if (mNavigationDrawerFragment.isDrawerOpen())
			mNavigationDrawerFragment.closeDrawer();
	}


    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
	/*	shareIntent.putExtra(Intent.EXTRA_STREAM, );
		mShare.setShareIntent(shareIntent);
	*/	
		
		
		return super.onCreateOptionsMenu(menu);
	}

@Override
	public void onNavigationDrawerItemSelected(int position) {
		Toast.makeText(this, "Menu item selected -> " + position, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onBackPressed() {
		if (mNavigationDrawerFragment.isDrawerOpen())
			mNavigationDrawerFragment.closeDrawer();
		else
			super.onBackPressed();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		Log.e("","id Inflater "+id);
		Log.e("","R,id "+R.id.shIcon);
		if (id == R.id.shIcon) {
			   		Intent intent = new Intent(this, SearchFriends.class);
					startActivity(intent);
					overridePendingTransition( android.R.anim.fade_in, android.R.anim.fade_out );
			return true;
		}
		if (id == R.id.friend_request) {
	  		Intent intent = new Intent(this,RecievedFriendRequest .class);
	  		Log.e("","EEXE");
			startActivity(intent);
			overridePendingTransition( android.R.anim.fade_in, android.R.anim.fade_out );
	return true;
}
		return super.onOptionsItemSelected(item);
	}
}
