package com.jatayu.main.map.look;



import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.LatLng;

public class Tab1Item {
	public String facebookIdAL ;
	public String usernameAL;	
	public String userstatusAL;	
	public String userTime;			
	public String userDate;				
	public LatLng  latlng;			
	public BitmapDescriptor bitmapDescAL;
	public String getFacebookIdAL() {
		return facebookIdAL;
	}
	public void setFacebookIdAL(String facebookIdAL) {
		this.facebookIdAL = facebookIdAL;
	}
	public String getUsernameAL() {
		return usernameAL;
	}
	public void setUsernameAL(String usernameAL) {
		this.usernameAL = usernameAL;
	}
	public String getUserstatusAL() {
		return userstatusAL;
	}
	public void setUserstatusAL(String userstatusAL) {
		this.userstatusAL = userstatusAL;
	}
	public String getUserTime() {
		return userTime;
	}
	public void setUserTime(String userTime) {
		this.userTime = userTime;
	}
	public String getUserDate() {
		return userDate;
	}
	public void setUserDate(String userDate) {
		this.userDate = userDate;
	}
	public LatLng getLatlng() {
		return latlng;
	}
	public void setLatlng(LatLng latlng) {
		this.latlng = latlng;
	}
	public BitmapDescriptor getBitmapDescAL() {
		return bitmapDescAL;
	}
	public void setBitmapDescAL(BitmapDescriptor bitmapDescAL) {
		this.bitmapDescAL = bitmapDescAL;
	}

}
