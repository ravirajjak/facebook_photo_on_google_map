package com.jatayu.main.map.sqlite;

import android.provider.BaseColumns;

public class PassKey {
		public 	PassKey()
		{
			
		}
		public static abstract  class TableInfo	implements BaseColumns
		{
			public static final String  DATABASE_NAME 		=	"jatayu_crypt";
			public static final String TABLE_NAME 					= 	"user_palace";
			public static final String MITRANO_USER_ID		=	"mitrano_user_id";
			public static final String FACEBOOK_ID					=	"facebook_id";
			public static final String USER_NAME					=	"user_name";
			public static final String EMAIL									=	"email";
			public static final String REGISTER_DATE			=	"register_date";
			public static final String REGISTER_TIME			=	"register_time";
			
			public static final String FRIENDS_TABLE  					= 	"friends_info";
			public static final String F_FACEBOOK_ID						=	"facebook_id";
			public static final String F_USER_NAME						=	"f_username";
			public static final String F_USER_STATUS						=	"f_status";
			public static final String F_LAT											=	"f_lat";
			public static final String F_LNG											=	"f_lng";
			public static final String F_DATE										=	"f_date";
			public static final String F_TIME										=	"f_time";
			
			
		}
}
