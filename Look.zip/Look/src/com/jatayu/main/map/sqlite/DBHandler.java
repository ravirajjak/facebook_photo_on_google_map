package com.jatayu.main.map.sqlite;



import com.jatayu.main.map.sqlite.PassKey.TableInfo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHandler  extends SQLiteOpenHelper{
	int counter=0;
	public static final int  database_version 	=	1;
	public String CREATE_QUERY =			"create table " + TableInfo.TABLE_NAME +  "("+
																				TableInfo.MITRANO_USER_ID+"  TEXT NOT NULL,"+
																				TableInfo.FACEBOOK_ID+ "  TEXT NOT NULL,"+ 
																				TableInfo.USER_NAME+" TEXT NOT NULL,"+
																				TableInfo.EMAIL+" TEXT NOT NULL)";
	public String CREATE_FRIEND_TABLE =			"create table " + TableInfo.FRIENDS_TABLE +  "("+
			TableInfo.F_USER_NAME+"  TEXT NOT NULL,"+
			TableInfo.F_FACEBOOK_ID+ "  TEXT NOT NULL,"+ 
			TableInfo.F_USER_STATUS+" TEXT NOT NULL,"+
			TableInfo.F_LAT+" TEXT NOT NULL,"+
			TableInfo.F_LNG+" TEXT NOT NULL,"+
			TableInfo.F_DATE+" TEXT NOT NULL,"+
			TableInfo.F_TIME+" TEXT NOT NULL)";
			
	public DBHandler(Context context) {
		super(context, TableInfo.DATABASE_NAME, null, database_version);
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase sdb){

		sdb.execSQL(CREATE_QUERY);
		sdb.execSQL(CREATE_FRIEND_TABLE);
		Log.d("","Table Createad");
	}
	

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}
	
	public int  putInformation(DBHandler dbh, String mitrano_id, String facebook_id, 
																	String user_name, String email_id){
			long k=0;
			SQLiteDatabase sqWrite= dbh.getWritableDatabase();
			ContentValues cv= new ContentValues();
			cv.put(TableInfo.MITRANO_USER_ID, mitrano_id);
			cv.put(TableInfo.FACEBOOK_ID, facebook_id);
			cv.put(TableInfo.USER_NAME,user_name);
			cv.put(TableInfo.EMAIL,email_id);
			k=sqWrite.insert(TableInfo.TABLE_NAME, null, cv);
			Log.e("USER TABLE",""+k);
			return (int)k;
	}
	
	
	
	

	public int  putInformation(DBHandler dbh, String f_name, String facebook_id, 
			String status,String lat, String lng,String date,String time){
			
	
		
		
			long k=0;
			SQLiteDatabase sqWrite= dbh.getWritableDatabase();
			if(counter<1)
				{
				sqWrite.execSQL("DROP TABLE IF EXISTS " + TableInfo.FRIENDS_TABLE);
				sqWrite.execSQL(CREATE_FRIEND_TABLE);
				}
			counter++;
			ContentValues cv= new ContentValues();
			cv.put(TableInfo.F_USER_NAME, f_name);
			cv.put(TableInfo.F_FACEBOOK_ID, facebook_id);
			cv.put(TableInfo.F_USER_STATUS,status);
			cv.put(TableInfo.F_LAT,lat);
			cv.put(TableInfo.F_LNG,lng);
			cv.put(TableInfo.F_DATE,date);
			cv.put(TableInfo.F_TIME,time);
			
			k=sqWrite.insert(TableInfo.FRIENDS_TABLE, null, cv);
			Log.e("ROW INSERTED FRIENDS TA ",""+k);
			return (int)k;
	}
	
	
	
	
	
	
	
	
	public Cursor readAllRow(DBHandler dbh){
		String readall= "select * from "+TableInfo.TABLE_NAME;
		SQLiteDatabase sq= 	dbh.getReadableDatabase();
		Cursor v= sq.rawQuery(readall, null);
		Log.e("v","READ AL CURSOR RETURRN  "+v);
		return v;
	}

	public Cursor readMitId(DBHandler dbh){
		String readall= "select "+TableInfo.MITRANO_USER_ID+" from "+TableInfo.TABLE_NAME;
		SQLiteDatabase sq= 	dbh.getReadableDatabase();
		Cursor v= sq.rawQuery(readall, null);
		Log.e("v","READ AL CURSOR RETURRN  "+DatabaseUtils.dumpCursorToString(v));
		return v;	}
	
	public Cursor readAllFriends(DBHandler dbh){
		String readall= "select * from "+TableInfo.FRIENDS_TABLE;
		SQLiteDatabase sq= 	dbh.getReadableDatabase();
		Cursor v= sq.rawQuery(readall, null);
		Log.e("v","READ AL CURSOR RETURRN  "+DatabaseUtils.dumpCursorToString(v));
		return v;	}

}
