/** Automatically generated file. DO NOT MODIFY */
package com.jatayu.main.map.look;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}